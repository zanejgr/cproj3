#include<stdio.h>
int main(){
	puts("not yet implemented");
	
}

