#define debug 0

#include "vdisk.h"
#include "oufs_lib.h"
#include "oufs_goodies.h"
#include <stdio.h>
int main(){
	puts("not yet implemented");
	return 1;
}

